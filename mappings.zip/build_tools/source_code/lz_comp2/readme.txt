This is the source code to Haruhiko Okumura's LZSS compressor, circa 1989.
It has been modified to output files in the "Saxman" LZSS compression format.

Sega undoubtably used Okumura's code when creating their own Saxman compressor.
As a result, this modified version generates identical files to those found in
the Sonic the Hedgehog 2 ROM.

You can find the original unaltered source code here:
https://web.archive.org/web/19990203141013/http://oak.oakland.edu/pub/simtelnet/msdos/arcutils/lz_comp2.zip
